#!/bin/bash
appium -p 4723 -bp 4724 --session-override
