#!/bin/bash
appium -p 4728 -bp 4727 --session-override
