#coding=utf-8

print "hello fuck"