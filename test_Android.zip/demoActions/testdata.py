#coding=utf-8

dic_Name = {}

dic_Name["accountA"] = "myat1"
dic_Name["accountB"] = "myat2"
dic_Name["accountC"] = "myat3"

accountA = dic_Name["accountA"]
accountB = dic_Name["accountB"]
accountC = dic_Name["accountC"]

dic_Group = {}
dic_Group["group0"] = 'GK1'
dic_Group["add_agree"] = "add_agree"
dic_Group["add_refuse"] = "add_refuse"
dic_Group["del_member"] = "del_member"
dic_Group["block_member"] = "block_member"
dic_Group["unblock_member"] = "unblock_member"
dic_Group["trans_owner"] = "trans_owner"
dic_Group["B_exit"] = "B_exit"
dic_Group["B_join"] = "B_join"

case_status = {}

