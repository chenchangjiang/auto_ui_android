#!/bin/bash
p=$(dirname $_)
python $p/demoActions/testRun.py
